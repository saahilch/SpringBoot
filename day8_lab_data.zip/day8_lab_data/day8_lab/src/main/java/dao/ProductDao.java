package dao;

import java.time.LocalDate;
import java.util.List;

import pojos.Product;
import pojos.ProductCategory;

public interface ProductDao {
//add a method to insert new product details
	String addNewProduct(Product product);

	// add a method to insert new product details : using get current session
	String addNewProductWithCurrentSession(Product product);

	// add a method to get all products
	List<Product> getAllProducts();

	// add a method to get all products by specific category
	List<Product> getAllProductsByCategory(ProductCategory category);
	//get id , name , price n stock of products by date
	List<Product>  getPartialDetailsByDate(LocalDate date);
	//update product price 
	String updateProductPrice(Integer productId,double priceOffset);
}
