package pojos;

public enum ProductCategory {
	BOOK, MAGAZINE, SHOES, CLOTHING
}
