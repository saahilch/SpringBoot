package com.app.controller;

import java.util.List;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.controller.Entities.Cources;
import com.app.controller.Services.CourceServices;

@RestController
public class MyController {

	@Autowired
	private CourceServices courceservice;

	@GetMapping("/Home")
	public String Home() {
		return "This Is Home Page";
	}

	@GetMapping("/Cources")
	public List<Cources> getCources() {
		return this.courceservice.getCources();

	}

	@GetMapping("/Cources/{CourceId}")
	public Cources getCourceById(@PathVariable String CourceId) {

		return this.courceservice.getCources(Long.parseLong(CourceId));

	}

	@PostMapping("/Cources")
	public Cources addCource(@RequestBody Cources cources) {
		return this.courceservice.addCource(cources);
	}

	@PutMapping("/Cources")
	public Cources updateCource(@RequestBody Cources cources) {
		return this.courceservice.updateCource(cources) ;
	}

	@DeleteMapping("/Cources/{CourceId}")
	public ResponseEntity<HttpStatus>deleteCource(@PathVariable String CourceId){
		try {
			this.courceservice.deleteCource(Long.parseLong(CourceId));
			return new ResponseEntity<>(HttpStatus.OK);
			
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
	}
}
