package com.app.controller.Services;

import java.util.List;

import com.app.controller.Entities.Cources;

public interface CourceServices {
	public List<Cources> getCources();

	public Cources getCources(long courceId);

	public Cources addCource(Cources cources);
	
	public Cources updateCource(Cources cources);

	public void deleteCource(long parseLong);
	
	

}
