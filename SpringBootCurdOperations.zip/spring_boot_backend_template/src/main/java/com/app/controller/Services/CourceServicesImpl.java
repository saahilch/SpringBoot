package com.app.controller.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.app.controller.Entities.Cources;

@Service
public class CourceServicesImpl implements CourceServices {

	List<Cources> list = new ArrayList<>();

	public CourceServicesImpl() {

		list.add(new Cources(22, "Java Cource ", "This Is Java Cource"));
		list.add(new Cources(12, "DotNet Cource ", "This Is DotNet Cource"));
		list.add(new Cources(21, "React Cource ", "This Is React Cource"));
	}

	@Override
	public List<Cources> getCources() {

		return list;
	}

	@Override
	public Cources getCources(long courceId) {
		Cources c = null;
		for (Cources cources : list) {
			if (cources.getId() == courceId) {
				c = cources;
				break;
			}

		}
		return c;
	}

	@Override
	public Cources addCource(Cources cources) {
		list.add(cources);
		return cources;
	}

	@Override
	public Cources updateCource(Cources cource) {

		list.forEach(e -> {
			if (e.getId() == cource.getId()) {
				e.setTitle(cource.getTitle());
				e.setDescription(cource.getDescription());
			}
		});
		return cource;

	}

	@Override
	public void deleteCource(long parseLong) {
		list = this.list.stream().filter(e ->
		e.getId() 
		!= parseLong).
		collect(Collectors.toList());

	}

}
