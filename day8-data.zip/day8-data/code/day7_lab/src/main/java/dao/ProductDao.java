package dao;

import pojos.Product;

public interface ProductDao {
//add a method to insert new product details
	String addNewProduct(Product product);
}
