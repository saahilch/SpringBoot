package dao;

import java.time.LocalDate;
import java.util.List;

import pojos.Employee;
import pojos.EmploymentType;

public interface EmployeeDao {
//add a method to insert new emp details
	String addNewEmployee(Employee trsnsientEmp);

	// add a method to insert new emp details : getCurrentSession
	String addNewEmployeeCurrentSession(Employee trsnsientEmp);

	// add a method to retrieve emp details by it's id
	Employee getEmployeeById(Integer id);

	// add a method to get list of all emps
	List<Employee> getAllEmps();

	// add a method to get emps by join date and salary
	List<Employee> getEmpsByJoinDateAndSalary(LocalDate beginDate, LocalDate endDate, double minSalary);

	// add a method to return last names of emps of specific emp type
	List<String> getLastNamesByEmploymentType(EmploymentType type);

	// add a method to get firstName , lastname n salary from all emps of a specific
	// emp type
	List<Employee> getEmpDetailsByEmpType(EmploymentType type);
}
