package dao;

import static utils.HibernateUtils.getFactory;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Employee;
import pojos.EmploymentType;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public String addNewEmployee(Employee emp) {
		// emp : TRANSIENT
		String mesg = "Adding emp details failed!!!!!";
		// 1. open session from SF
		Session session = getFactory().openSession();
		Session session2 = getFactory().openSession();
		System.out.println(session == session2);// f

		// 2. begin Tx
		Transaction tx = session.beginTransaction();
		// for checking
		System.out.println("session is open " + session.isOpen() + " is connected " + session.isConnected());// t t
		try {
			Serializable empId = session.save(emp);
			// emp : PERSISTENT
			System.out.println("generated id " + empId);
			tx.commit();
			/*
			 * Hibernate performs : session.flush() --> auto dirty checking --> checks the
			 * state of L1 cache --with DB -- new entity in L1 -- DML : insert
			 */
			mesg = "Added emp details with id=" + empId;
			// for checking
			System.out.println(
					"after commit : session is open " + session.isOpen() + " is connected " + session.isConnected());// t
																														// t
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		} finally {
			if (session != null)
				session.close();
		}
		// for checking
		System.out.println("session is open " + session.isOpen() + " is connected " + session.isConnected());// f f

		return mesg;
	}

	@Override
	public String addNewEmployeeCurrentSession(Employee emp) {
		// emp : TRANSIENT
		String mesg = "Adding emp details failed!!!!!";
		// 1. open session from SF
		Session session = getFactory().getCurrentSession();
		Session session2 = getFactory().getCurrentSession();
		System.out.println(session == session2);// t

		// 2. begin Tx
		Transaction tx = session.beginTransaction();
		// for checking
		System.out.println("session is open " + session.isOpen() + " is connected " + session.isConnected());// t t
		try {
			Serializable empId = session.save(emp);
			// emp : PERSISTENT (=> part of L1 cache , BUT rec is not yet inserted in DB)
			System.out.println("generated id " + empId);
			tx.commit();
			// emp : DETACHED (=> not a part of L1 cache BUT a part DB)
			/*
			 * Hibernate performs : session.flush() --> auto dirty checking --> checks the
			 * state of L1 cache --with DB -- new entity in L1 -- DML : insert ,
			 * session.close() -- L1 cache is destroyed , pooled out db cn rets to the pool
			 */
			mesg = "Added emp details with id=" + empId;
			// for checking
			System.out.println(
					"after commit : session is open " + session.isOpen() + " is connected " + session.isConnected());// f
																														// f
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			System.out.println(
					"after rollback : session is open " + session.isOpen() + " is connected " + session.isConnected());// f
																														// f
			/*
			 * session.close() -- L1 cache is destroyed , pooled out db cn rets to the pool
			 */
			throw e;
		}
		return mesg;
	}

	@Override
	public Employee getEmployeeById(Integer id) {
		Employee emp = null;// emp : DOES not exist !
		// 1. get session from SF
		Session session = getFactory().getCurrentSession();
		// 2. Begin a tx
		Transaction tx = session.beginTransaction();
		try {
			System.out.println("session contains entity " + session.contains(emp));
			emp = session.get(Employee.class, id);// Integer --> Serializable : up casting, select
			// emp : in case of existing id : PERSISTENT (part of L1 cache , part of DB)
			// emp : null (in case of non existing id)
			System.out.println("session contains entity " + session.contains(emp));

//			emp = session.get(Employee.class, id);
//			emp = session.get(Employee.class, id);
//			emp = session.get(Employee.class, id);
//			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return emp;
	}

	@Override
	public List<Employee> getAllEmps() {
		List<Employee> empList = null;
		String jpql = "select e from Employee e";
		// 1. Get session from SF
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			empList = session.createQuery(jpql, Employee.class).getResultList();
//			empList=session.createQuery(jpql, Employee.class)
//					.getResultList();
//			empList=session.createQuery(jpql, Employee.class)
//					.getResultList();
			// empList : list of persistent entities
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return empList;// empList : list of detached entities
	}

	@Override
	public List<Employee> getEmpsByJoinDateAndSalary(LocalDate beginDate, LocalDate endDate, double minSalary) {
		List<Employee> emps = null;
		String jpql = "select e from Employee e where e.joinDate between :start and :end and e.salary>:min";
		// 1. Get session from SF
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			emps = session.createQuery(jpql, Employee.class).setParameter("start", beginDate)
					.setParameter("end", endDate).setParameter("min", minSalary).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return emps;
	}

	@Override
	public List<String> getLastNamesByEmploymentType(EmploymentType type) {
		List<String> lastNames = null;
		String jpql = "select e.lastName from Employee e where e.empType=:ty";
		// 1. Get session from SF
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			lastNames = session.createQuery(jpql, String.class).setParameter("ty", type).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return lastNames;
	}

	@Override
	public List<Employee> getEmpDetailsByEmpType(EmploymentType type1) {
		List<Employee> emps=null;
		String jpql="select new pojos.Employee(firstName,lastName,salary) from Employee e where e.empType=:type";
		// 1. Get session from SF
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			emps=session.createQuery(jpql, Employee.class)
					.setParameter("type", type1)
					.getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return emps;
	}

}
